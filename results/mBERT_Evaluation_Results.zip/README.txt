mBERT Evaluation Results

Validation samples: 1209
Metrics computed from saved validation predictions only.
Training samples are excluded.
Scores use the 0-to-1 scale.

Class order: Favour, Against, None.
Confusion matrix rows: actual labels.
Confusion matrix columns: predicted labels.
Language-wise Precision and Recall use macro averaging.

Hindi/Bengali samples are synthetic translations.
These are supplied-validation results, not independent teacher-test results.
Model weights are not included.
