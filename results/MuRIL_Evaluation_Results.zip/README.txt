MuRIL Evaluation Results

This ZIP follows the four-CSV structure of the supplied XLM-R results ZIP.

Files:
- overall_metrics.csv: overall validation metrics supplied by the user. Micro F1, balanced accuracy and MCC are derivable from the supplied confusion matrix.
- classification_report.csv: class-wise metrics supplied by the user.
- confusion_matrix.csv: supplied confusion matrix, reordered to Favour, Against, None to match the reference ZIP.
- language_wise_metrics.csv: language rows included, but metric values are intentionally blank because language-wise predictions/metrics were not supplied. Do not treat these as zero.

Validation set size: 1,209.
Class supports: Against=168, Favour=513, None=528.

Note: The overall metrics and classification report are reproduced from the values provided in chat. Rounded values may cause tiny differences when independently recomputed.
